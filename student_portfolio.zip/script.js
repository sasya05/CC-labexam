// Small JS for contact form and year
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contactForm');
form.addEventListener('submit', function(e){
  e.preventDefault();
  const status = document.getElementById('formStatus');
  const formData = new FormData(form);
  // This is a static template — in a real site you'd send to an API.
  status.textContent = 'Thanks ' + (formData.get('name')||'') + ', your message was recorded (demo-only).';
  form.reset();
});
