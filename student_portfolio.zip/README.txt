Student Portfolio Template
--------------------------
Files in this template:
- index.html      : Main portfolio page
- styles.css      : Styling
- script.js       : Tiny interactivity (contact form demo)
- profile.png     : Placeholder profile image
- resume.pdf      : Simple resume placeholder
- README.txt      : This file

How to use:
1. Unzip the archive.
2. Open index.html in a browser to preview.
3. Replace placeholders (Your Name, resume.pdf, images, links) with your content.

License: MIT-style — use and modify freely.
